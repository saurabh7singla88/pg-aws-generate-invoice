import PDFDocument from 'pdfkit';

/**
 * Generates a PDF invoice from invoice data
 * @param {Object} data - Invoice data containing order, customer, line items, and totals
 * @returns {Promise<Buffer>} PDF buffer
 */
export function generateInvoicePDF(data) {
    return new Promise((resolve, reject) => {
        const doc = new PDFDocument({ 
            size: 'A4',
            margins: { top: 50, bottom: 50, left: 50, right: 50 }
        });
        
        const chunks = [];
        
        // Collect PDF data
        doc.on('data', chunk => chunks.push(chunk));
        doc.on('end', () => resolve(Buffer.concat(chunks)));
        doc.on('error', reject);
        
        // --- HEADER SECTION ---
        // Company Logo & Name (Left)
        doc.fontSize(24)
           .fillColor('#10b981')
           .text('PistaGreen', 50, 50);
        
        doc.fontSize(10)
           .fillColor('#6b7280')
           .text('123 Market Street, Suite 500', 50, 80)
           .text('San Francisco, CA 94103', 50, 95)
           .text('billing@pistagreen.com', 50, 110)
           .text('(555) 123-4567', 50, 125);
        
        // Invoice Title (Right)
        doc.fontSize(28)
           .fillColor('#111827')
           .text('INVOICE', 300, 50, { width: 245, align: 'right' });
        
        doc.fontSize(11)
           .fillColor('#6b7280')
           .text(data.order.name, 300, 85, { width: 245, align: 'right' })
           .text(data.order.date, 300, 105, { width: 245, align: 'right' });
        
        // Horizontal line
        doc.moveTo(50, 160)
           .lineTo(545, 160)
           .strokeColor('#e5e7eb')
           .stroke();
        
        // --- INFO SECTION (3 columns) ---
        let yPos = 180;
        
        // Bill To
        doc.fontSize(12)
           .fillColor('#6b7280')
           .text('BILL TO', 50, yPos);
        
        yPos += 20;
        doc.fontSize(11)
           .fillColor('#111827')
           .text(data.customer.name, 50, yPos);
        
        if (data.customer.company) {
            yPos += 15;
            doc.text(data.customer.company, 50, yPos);
        }
        
        yPos += 15;
        doc.fillColor('#6b7280')
           .text(data.customer.email, 50, yPos);
        
        if (data.customer.phone) {
            yPos += 15;
            doc.text(data.customer.phone, 50, yPos);
        }
        
        // Ship To
        yPos = 180;
        doc.fontSize(12)
           .fillColor('#6b7280')
           .text('SHIP TO', 220, yPos);
        
        yPos += 20;
        doc.fontSize(11)
           .fillColor('#111827')
           .text(data.shippingAddress.name, 220, yPos);
        
        yPos += 15;
        doc.text(data.shippingAddress.address, 220, yPos);
        
        yPos += 15;
        doc.text(`${data.shippingAddress.city}, ${data.shippingAddress.state} ${data.shippingAddress.zip}`, 220, yPos);
        
        // Invoice Details
        yPos = 180;
        doc.fontSize(11)
           .fillColor('#6b7280')
           .text('INVOICE DETAILS', 380, yPos);
        
        yPos += 25;
        doc.fontSize(10)
           .fillColor('#6b7280')
           .text('Invoice Number:', 380, yPos);
        doc.fillColor('#111827')
           .text(data.order.name, 475, yPos);
        
        yPos += 18;
        doc.fillColor('#6b7280')
           .text('Invoice Date:', 380, yPos);
        doc.fillColor('#111827')
           .text(data.order.date, 475, yPos, { width: 100 });
        
        if (data.order.dueDate) {
            yPos += 18;
            doc.fillColor('#6b7280')
               .text('Due Date:', 380, yPos);
            doc.fillColor('#111827')
               .text(data.order.dueDate, 475, yPos, { width: 100 });
        }
        
        if (data.order.poNumber) {
            yPos += 18;
            doc.fillColor('#6b7280')
               .text('PO Number:', 380, yPos);
            doc.fillColor('#111827')
               .text(data.order.poNumber, 475, yPos);
        }
        
        // --- LINE ITEMS TABLE ---
        yPos = 320;
        
        // Table header background
        doc.rect(50, yPos, 495, 25)
           .fillColor('#f3f4f6')
           .fill();
        
        // Table headers
        doc.fontSize(10)
           .fillColor('#374151')
           .text('ITEM', 60, yPos + 8)
           .text('QTY', 350, yPos + 8)
           .text('UNIT PRICE', 400, yPos + 8)
           .text('TOTAL', 490, yPos + 8, { align: 'right' });
        
        yPos += 35;
        
        // Table rows
        data.lineItems.forEach((item, index) => {
            // Alternate row background
            if (index % 2 === 0) {
                doc.rect(50, yPos - 5, 495, 30)
                   .fillColor('#fafafa')
                   .fill();
            }
            
            doc.fontSize(10)
               .fillColor('#111827')
               .text(item.name, 60, yPos, { width: 280 });
            
            if (item.description) {
                doc.fontSize(9)
                   .fillColor('#6b7280')
                   .text(item.description, 60, yPos + 12, { width: 280 });
            }
            
            doc.fontSize(10)
               .fillColor('#111827')
               .text(item.quantity, 350, yPos)
               .text(item.unitPrice, 400, yPos)
               .text(item.lineTotal, 490, yPos, { align: 'right' });
            
            yPos += 35;
        });
        
        // Line above totals
        yPos += 10;
        doc.moveTo(350, yPos)
           .lineTo(545, yPos)
           .strokeColor('#e5e7eb')
           .stroke();
        
        // --- TOTALS SECTION ---
        yPos += 20;
        
        // Subtotal
        doc.fontSize(10)
           .fillColor('#6b7280')
           .text('Subtotal:', 380, yPos);
        doc.fillColor('#111827')
           .text(data.totals.subtotal, 460, yPos, { width: 85, align: 'right' });
        
        // Discount (if exists)
        if (data.totals.discount) {
            yPos += 20;
            doc.fillColor('#6b7280')
               .text('Discount:', 380, yPos);
            doc.fillColor('#dc2626')
               .text(data.totals.discount, 460, yPos, { width: 85, align: 'right' });
        }
        
        // Shipping (if exists)
        if (data.totals.shipping) {
            yPos += 20;
            doc.fillColor('#6b7280')
               .text('Shipping:', 380, yPos);
            doc.fillColor('#111827')
               .text(data.totals.shipping, 460, yPos, { width: 85, align: 'right' });
        }
        
        // Tax
        yPos += 20;
        doc.fillColor('#6b7280')
           .text('Tax:', 380, yPos);
        doc.fillColor('#111827')
           .text(data.totals.tax, 460, yPos, { width: 85, align: 'right' });
        
        // Total (highlighted)
        yPos += 25;
        doc.rect(330, yPos - 8, 215, 30)
           .fillColor('#10b981')
           .fill();
        
        doc.fontSize(12)
           .fillColor('#ffffff')
           .text('TOTAL:', 380, yPos);
        doc.fontSize(14)
           .text(data.totals.total, 460, yPos, { width: 85, align: 'right' });
        
        // --- NOTES SECTION ---
        yPos += 60;
        if (data.order.notes) {
            doc.fontSize(12)
               .fillColor('#6b7280')
               .text('NOTES', 50, yPos);
            
            yPos += 20;
            doc.fontSize(10)
               .fillColor('#111827')
               .text(data.order.notes, 50, yPos, { width: 495 });
        }
        
        // --- FOOTER ---
        doc.fontSize(9)
           .fillColor('#9ca3af')
           .text('Thank you for your order!', 50, 750, { align: 'center', width: 495 });
        
        doc.end();
    });
}
