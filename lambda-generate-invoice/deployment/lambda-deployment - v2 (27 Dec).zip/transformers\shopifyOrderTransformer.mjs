/**
 * Transforms a Shopify order webhook payload into invoice data format
 * @param {Object} shopifyOrder - The Shopify order object
 * @returns {Object} Formatted invoice data
 */
export function transformShopifyOrderToInvoice(shopifyOrder) {
    return {
        order: {
            name: `#${shopifyOrder.name || shopifyOrder.order_number}`,
            date: new Date(shopifyOrder.created_at).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            }),
            dueDate: shopifyOrder.payment_terms?.due_in_days 
                ? new Date(Date.now() + shopifyOrder.payment_terms.due_in_days * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                })
                : null,
            poNumber: shopifyOrder.po_number || null,
            notes: shopifyOrder.note || 'Thank you for your order!'
        },
        customer: {
            name: shopifyOrder.customer 
                ? `${shopifyOrder.customer.first_name || ''} ${shopifyOrder.customer.last_name || ''}`.trim()
                : shopifyOrder.billing_address?.name || 'Guest',
            company: shopifyOrder.billing_address?.company || null,
            email: shopifyOrder.email || shopifyOrder.customer?.email || '',
            phone: shopifyOrder.phone || shopifyOrder.customer?.phone || shopifyOrder.billing_address?.phone || null
        },
        shippingAddress: {
            name: shopifyOrder.shipping_address?.name || shopifyOrder.billing_address?.name || '',
            address: `${shopifyOrder.shipping_address?.address1 || ''} ${shopifyOrder.shipping_address?.address2 || ''}`.trim(),
            city: shopifyOrder.shipping_address?.city || '',
            state: shopifyOrder.shipping_address?.province || '',
            zip: shopifyOrder.shipping_address?.zip || ''
        },
        lineItems: shopifyOrder.line_items?.map(item => ({
            name: item.title || item.name,
            description: item.variant_title ? `Variant: ${item.variant_title}` : null,
            sku: item.sku || null,
            quantity: item.quantity,
            unitPrice: `${shopifyOrder.currency} ${parseFloat(item.price).toFixed(2)}`,
            lineTotal: `${shopifyOrder.currency} ${(item.quantity * parseFloat(item.price)).toFixed(2)}`
        })) || [],
        totals: {
            subtotal: `${shopifyOrder.currency} ${parseFloat(shopifyOrder.current_subtotal_price || shopifyOrder.subtotal_price).toFixed(2)}`,
            discount: shopifyOrder.current_total_discounts && parseFloat(shopifyOrder.current_total_discounts) > 0
                ? `-${shopifyOrder.currency} ${parseFloat(shopifyOrder.current_total_discounts).toFixed(2)}`
                : null,
            shipping: shopifyOrder.total_shipping_price_set?.shop_money?.amount && parseFloat(shopifyOrder.total_shipping_price_set.shop_money.amount) > 0
                ? `${shopifyOrder.currency} ${parseFloat(shopifyOrder.total_shipping_price_set.shop_money.amount).toFixed(2)}`
                : null,
            tax: `${shopifyOrder.currency} ${parseFloat(shopifyOrder.current_total_tax || shopifyOrder.total_tax).toFixed(2)}`,
            total: `${shopifyOrder.currency} ${parseFloat(shopifyOrder.current_total_price || shopifyOrder.total_price).toFixed(2)}`
        }
    };
}

/**
 * Parses the Shopify webhook event body
 * @param {Object} event - Lambda event object
 * @returns {Object} Parsed Shopify order
 */
export function parseShopifyWebhook(event) {
    return typeof event.body === 'string' 
        ? JSON.parse(event.body) 
        : event.body || event;
}
