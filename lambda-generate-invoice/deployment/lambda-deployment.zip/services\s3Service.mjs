import { PutObjectCommand } from '@aws-sdk/client-s3';
import { s3Client } from '../config/awsClients.mjs';

/**
 * Uploads a PDF buffer to S3
 * @param {Buffer} pdfBuffer - The PDF file buffer
 * @param {string} orderName - Order name/number for filename
 * @returns {Promise<Object>} Object with fileName and s3Url
 */
export async function uploadInvoiceToS3(pdfBuffer, orderName) {
    const fileName = `invoices/invoice-${orderName.replace('#', '')}-${Date.now()}.pdf`;
    const uploadParams = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: fileName,
        Body: pdfBuffer,
        ContentType: 'application/pdf'
    };
    
    await s3Client.send(new PutObjectCommand(uploadParams));
    console.log(`PDF uploaded to S3: ${fileName}`);
    
    const s3Url = `https://${process.env.S3_BUCKET_NAME}.s3.${process.env.AWS_REGION || 'us-east-1'}.amazonaws.com/${fileName}`;
    
    return { fileName, s3Url };
}
